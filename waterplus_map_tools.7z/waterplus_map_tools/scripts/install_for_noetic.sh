#!/bin/bash
sudo apt-get update
sudo apt-get install ros-noetic-map-server
sudo apt-get install ros-noetic-navigation