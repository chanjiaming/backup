#!/bin/bash
sudo apt-get update
sudo apt-get install ros-kinetic-map-server
sudo apt-get install ros-kinetic-navigation