import rospy
from geometry_msgs.msg import PoseStamped

# Initialize the ROS node
rospy.init_node('waypoint_publisher')

# Create a publisher for the waypoint
waypoint_pub = rospy.Publisher('/waypoint_with_orientation', PoseStamped, queue_size=10)

# Define a PoseStamped message
waypoint = PoseStamped()
waypoint.header.frame_id = "map"
waypoint.header.stamp = rospy.Time.now()

# Set the position (x, y, z)
waypoint.pose.position.x = 2.0
waypoint.pose.position.y = 3.0
waypoint.pose.position.z = 0.0

# Set the orientation using quaternion (x, y, z, w)
waypoint.pose.orientation.x = 0.0
waypoint.pose.orientation.y = 0.0
waypoint.pose.orientation.z = 0.707
waypoint.pose.orientation.w = 0.707

# Publish the waypoint
waypoint_pub.publish(waypoint)

rospy.loginfo("Published waypoint with position and orientation.")
