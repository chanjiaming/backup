#!/usr/bin/env python3

import rospy
from interactive_markers.interactive_marker_server import *
from visualization_msgs.msg import *
from geometry_msgs.msg import PoseStamped

def process_feedback(feedback):
    # Create a PoseStamped message from the marker position
    pose = PoseStamped()
    pose.header.frame_id = "map"
    pose.header.stamp = rospy.Time.now()
    pose.pose = feedback.pose

    # Publish the pose to a topic, e.g., '/waypoint'
    print("publish point")
    waypoint_pub.publish(pose)
    
    rospy.loginfo("New waypoint set: (%.2f, %.2f, %.2f)", feedback.pose.position.x, feedback.pose.position.y, feedback.pose.position.z)

if __name__ == "__main__":
    rospy.init_node("waypoint_marker")

    # Create a publisher for the waypoint
    waypoint_pub = rospy.Publisher('/waypoint', PoseStamped, queue_size=10)

    # Create the interactive marker server
    server = InteractiveMarkerServer("waypoint_marker_server")

    # Create an interactive marker
    int_marker = InteractiveMarker()
    int_marker.header.frame_id = "map"
    int_marker.name = "waypoint_marker"
    int_marker.description = "Waypoint Marker"
    int_marker.pose.position.x = 0.0
    int_marker.pose.position.y = 0.0
    int_marker.pose.position.z = 0.0

    # Create a control to move the marker in 3D space
    move_control = InteractiveMarkerControl()
    move_control.name = "move_xy"
    move_control.interaction_mode = InteractiveMarkerControl.MOVE_PLANE

    # Create a simple box marker
    box_marker = Marker()
    box_marker.type = Marker.CUBE
    box_marker.scale.x = 0.2
    box_marker.scale.y = 0.2
    box_marker.scale.z = 0.2
    box_marker.color.r = 0.0
    box_marker.color.g = 1.0
    box_marker.color.b = 0.0
    box_marker.color.a = 1.0

    move_control.markers.append(box_marker)
    int_marker.controls.append(move_control)

    # Add the marker to the server
    server.insert(int_marker, process_feedback)

    # Apply changes to the server
    server.applyChanges()

    rospy.spin()
