#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Pose, PoseStamped, Point, Quaternion
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
import actionlib
from std_msgs.msg import Bool
import time

class WaypointNavigator:
    def __init__(self):
        self.client = actionlib.SimpleActionClient('move_base', MoveBaseAction)
        self.client.wait_for_server()

        self.activate_detection_pub = rospy.Publisher('/activate_detection', Bool, queue_size=10)
        self.resume_waypoint_sub = rospy.Subscriber('/resume_waypoint', Bool, self.resume_waypoint_callback)
        self.person_centered_sub = rospy.Subscriber('/person_centered', Bool, self.person_centered_callback)
        
        self.pause = False
        self.ignore_person_centered = False  # Flag to ignore person_centered for a duration
        self.current_goal = None  # Store the current goal

    def send_waypoints(self, waypoints):
        for i, waypoint in enumerate(waypoints):
            if not self.pause:  # Ensure we are not paused before sending the next waypoint
                goal = MoveBaseGoal()
                goal.target_pose.header.frame_id = "map"
                goal.target_pose.header.stamp = rospy.Time.now()

                goal.target_pose.pose = waypoint

                rospy.loginfo(f"Sending waypoint {i+1}")
                self.client.send_goal(goal)
                self.current_goal = goal  # Store the current goal

                while not self.client.wait_for_result(rospy.Duration(1.0)):
                    if self.pause:
                        rospy.loginfo("Paused due to person detection. Waiting for resume signal...")
                        self.client.cancel_goal()
                        return  # Exit the function to avoid moving to the next waypoint
                rospy.loginfo(f"Waypoint {i+1} reached or timeout reached")

        rospy.loginfo("All waypoints processed")  # Only called when all waypoints are processed

    def person_centered_callback(self, msg):
        if msg.data and not self.ignore_person_centered:
            rospy.loginfo("Person centered detected, stopping and activating detection.")
            self.pause = True
            self.activate_detection_pub.publish(True)

    def resume_waypoint_callback(self, msg):
        if msg.data and self.pause:
            rospy.loginfo("Resume signal received, resuming waypoint navigation.")
            self.pause = False
            self.ignore_person_centered = True
            self.send_current_waypoint()

            # Ignore person_centered for 2 seconds
            time.sleep(2)
            self.ignore_person_centered = False
            rospy.loginfo("Resuming person-centered detection after 2 seconds.")

    def send_current_waypoint(self):
        # Resume from the stored goal
        if self.current_goal:
            self.client.send_goal(self.current_goal)
            self.client.wait_for_result(rospy.Duration.from_sec(30.0))
            rospy.loginfo("Resumed and waypoint reached")

if __name__ == '__main__':
    rospy.init_node('navigation_with_waypoints')
    
    navigator = WaypointNavigator()

    # Define multiple waypoints
    waypoints = [
        Pose(position=Point(1.31, 3.55, 0.0031), orientation=Quaternion(0.0, 0.0, 0.0, 1.0)),
    ]

    # Send the waypoints to the robot
    navigator.send_waypoints(waypoints)

    rospy.loginfo("All waypoints processed")
    rospy.spin()
