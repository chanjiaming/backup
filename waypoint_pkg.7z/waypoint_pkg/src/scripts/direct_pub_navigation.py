#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import PoseStamped, Point, Quaternion, Pose

def publish_waypoints(waypoints):
    goal_pub = rospy.Publisher('/move_base_simple/goal', PoseStamped, queue_size=10)
    rospy.sleep(2)  # Add a delay to ensure everything is ready

    for i, waypoint in enumerate(waypoints):
        goal = PoseStamped()
        goal.header.frame_id = "map"
        goal.header.stamp = rospy.Time.now()
        goal.pose = waypoint

        rospy.loginfo(f"Publishing waypoint {i+1}")
        goal_pub.publish(goal)
        rospy.sleep(1)  # Add a small delay to give the robot time to process each goal

if __name__ == '__main__':
    rospy.init_node('navigation_with_direct_publishing')

    # Define multiple waypoints
    waypoints = [    
        Pose(position=Point(1.31, 3.55, 0.0031), orientation=Quaternion(0.0, 0.0, 0.707, 0.707)),
        Pose(position=Point(6.45, 6.02, 0.00391), orientation=Quaternion(0.0, 0.0, 0.0, 1.0)),
    ]

    # Publish the waypoints
    publish_waypoints(waypoints)

    rospy.loginfo("All waypoints published")
    rospy.spin()
