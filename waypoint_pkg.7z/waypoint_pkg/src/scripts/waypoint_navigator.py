#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import PoseStamped
import csv

def send_goal(x, y):
    goal = PoseStamped()
    goal.header.frame_id = "map"
    goal.header.stamp = rospy.Time.now()

    goal.pose.position.x = x
    goal.pose.position.y = y
    goal.pose.orientation.w = 1.0  # Facing forward

    pub.publish(goal)
    rospy.loginfo(f"Goal sent to x: {x}, y: {y}")
    rospy.sleep(1)

def navigate_waypoints():
    rospy.init_node('waypoint_navigator', anonymous=True)
    global pub
    pub = rospy.Publisher('/move_base_simple/goal', PoseStamped, queue_size=10)

    with open("/home/eevee/catkin_ws/waypoints.csv", "r") as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        for row in reader:
            x, y = float(row[0]), float(row[1])
            send_goal(x, y)

    rospy.loginfo("Navigation to all waypoints complete.")

if __name__ == '__main__':
    navigate_waypoints()
