^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package kobuki_apps
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.6.6 (2015-05-27)
------------------

0.6.5 (2014-11-21)
------------------

0.6.4 (2014-08-26)
------------------

0.6.3 (2014-08-25)
------------------
* rename_kobuki_apps to kobuki_Rapps
* Contributors: Jihoon Lee

0.6.2 (2014-08-11)
------------------

0.6.1 (2014-08-08)
------------------

0.6.0 (2014-08-08)
------------------
* sync package version. remove author e-mail
* updates icons for apps and app manager launcher
* adds minor changes due to capability server and app manager updates
* updates for new rapp lists
* kobuki_apps: fixes spelling mistake in run dependency
* adds cleanup and updates for the recent changes in capabilities dev
* kobuki_apps: adds provider specific remappings for random walker app
* adds kobuki_apps
* Contributors: Jihoon Lee, Marcus Liebhardt

* updates icons for apps and app manager launcher
* adds minor changes due to capability server and app manager updates
* updates for new rapp lists
* kobuki_apps: fixes spelling mistake in run dependency
* adds cleanup and updates for the recent changes in capabilities dev
* kobuki_apps: adds provider specific remappings for random walker app
* adds kobuki_apps
* Contributors: Marcus Liebhardt

0.5.6 (2014-05-23)
------------------

0.5.5 (2013-10-11)
------------------

0.5.4 (2013-09-11)
------------------

0.5.3 (2013-08-30 12:30)
------------------------

0.5.2 (2013-08-30 01:44)
------------------------

0.5.1 (2013-08-30 01:43)
------------------------

0.5.0 (2013-08-29)
------------------

0.4.0 (2013-08-09)
------------------

0.3.9 (2013-06-04)
------------------

0.3.8 (2013-05-22)
------------------

0.3.7 (2013-04-16)
------------------

0.3.6 (2013-02-28)
------------------

0.3.5 (2013-02-19)
------------------

0.3.4 (2013-02-10 13:29)
------------------------

0.3.3 (2013-02-10 00:19)
------------------------

0.3.2 (2013-02-08 23:31)
------------------------

0.3.1 (2013-02-08 17:28)
------------------------

0.2.4 (2013-01-21)
------------------

0.2.3 (2013-01-16)
------------------

0.2.2 (2013-01-02)
------------------

0.2.1 (2012-12-22)
------------------

0.2.0 (2012-12-21 19:37)
------------------------

0.1.9 (2012-12-21 19:35)
------------------------

0.1.8 (2012-12-10)
------------------

0.1.7 (2012-12-05)
------------------

0.1.5 (2012-11-22)
------------------

0.1.4 (2012-11-21)
------------------

0.1.3 (2012-11-16)
------------------

0.1.2 (2012-11-03)
------------------

0.1.1 (2012-11-05)
------------------
* we moved out kobuki apps to their own repo, closes `#102 <https://github.com/yujinrobot/kobuki/issues/102>`_.
* kobuki follower added and upgraded for new kinect.
* Load kinect_frames.launch from openni_camera_deprecated package. Fix
  failure in android_map_nav app.
* Contributors: Jorge Santos, Kim Min Soo

0.1.0 (2012-04-20)
------------------
* trivial fixes to docs and rosinstaller.
* kobuki_driver : digital outputs, also chirp working on robot.
* kobuki_apps : map_loader changed name to map_manager.
* android teleop working, map nav starting, but cant find map_loader.
* kobuki apps for teleop and amcl.
* kobuki_bringup : denamespaced, about to test.
* kobuki_apps : move scan topic.
* started testing android apps.
* Contributors: Daniel Stonier
