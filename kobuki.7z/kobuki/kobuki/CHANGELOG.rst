^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package kobuki
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.6.6 (2015-05-27)
------------------

0.6.5 (2014-11-21)
------------------

0.6.4 (2014-08-26)
------------------

0.6.3 (2014-08-25)
------------------
* remove authors e-mail
* rename kobuki_apps as kobuki_rapps to resolve `#336 <https://github.com/yujinrobot/kobuki/issues/336>`_
* Contributors: Jihoon Lee

0.6.2 (2014-08-11)
------------------

0.6.1 (2014-08-08)
------------------

0.6.0 (2014-08-08)
------------------
* Add missing run dependency on yocs_cmd_vel_mux
* Contributors: Jorge Santos

0.5.5 (2013-10-11)
------------------

0.5.4 (2013-09-06)
------------------
* Fix the list of packages on this stack.

0.5.3 (2013-08-30)
------------------
* ros and non-ros stack split, driver, ftdi and auto-docking (partial) gone to kobuki_core.

0.5.0 (2013-08-29)
------------------
* adds eclipse project files.
* adds the kobuki random walker to the kobuki metapackage.
* Added extra url info on all packages.
* Updated old rnd email address.
* Fix URL to the previous changelog wiki.
* Changelogs at package level.

0.4.0 (2013-08-09)
------------------


Previous versions, bugfixing
============================

Available in ROS wiki: http://ros.org/wiki/kobuki/ChangeList
