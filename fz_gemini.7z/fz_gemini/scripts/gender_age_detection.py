#!/home/eevee/catkin_ws/src/fz_gemini/.venv/bin/python3

import os
import rospy
import cv2
import json
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
from std_srvs.srv import Trigger, TriggerResponse

from config import BASE_PATH

class GenderAgeDetectionService:
    def __init__(self):
        self.bridge = CvBridge()
        self.faceProto = os.path.join(BASE_PATH, "gender_age_model/opencv_face_detector.pbtxt")
        self.faceModel = os.path.join(BASE_PATH, "gender_age_model/opencv_face_detector_uint8.pb")
        self.ageProto = os.path.join(BASE_PATH, "gender_age_model/age_deploy.prototxt")
        self.ageModel = os.path.join(BASE_PATH, "gender_age_model/age_net.caffemodel")
        self.genderProto = os.path.join(BASE_PATH, "gender_age_model/gender_deploy.prototxt")
        self.genderModel = os.path.join(BASE_PATH, "gender_age_model/gender_net.caffemodel")

        self.faceNet = cv2.dnn.readNet(self.faceModel, self.faceProto)
        self.ageNet = cv2.dnn.readNet(self.ageModel, self.ageProto)
        self.genderNet = cv2.dnn.readNet(self.genderModel, self.genderProto)

        rospy.Service('gender_age_detection', Trigger, self.handle_detection)
        rospy.loginfo("Gender and Age Detection Service is ready.")

    def handle_detection(self, req):
        image_path = os.path.join(BASE_PATH, "img/captured_image.jpg")
        frame = cv2.imread(image_path)
        
        if frame is None:
            rospy.logerr("Failed to load the image for gender and age detection.")
            return TriggerResponse(success=False, message="Failed to load the image.")

        result_img, face_boxes = self.highlight_face(self.faceNet, frame)
        if not face_boxes:
            rospy.loginfo("No face detected.")
            return TriggerResponse(success=False, message="No face detected.")

        for face_box in face_boxes:
            face = frame[max(0, face_box[1] - 20):min(face_box[3] + 20, frame.shape[0]),
                        max(0, face_box[0] - 20):min(face_box[2] + 20, frame.shape[1])]
            
            blob = cv2.dnn.blobFromImage(face, 1.0, (227, 227), (78.4263377603, 87.7689143744, 114.895847746), swapRB=False)
            self.genderNet.setInput(blob)
            gender_preds = self.genderNet.forward()
            gender = "Male" if gender_preds[0].argmax() == 0 else "Female"

            self.ageNet.setInput(blob)
            age_preds = self.ageNet.forward()
            age_ranges = ['0-2', '4-6', '8-12', '13-18', '19-32', '38-43', '48-53', '60-100']
            age = age_ranges[age_preds[0].argmax()]

            # Convert age from "4-6" to "4 to 6"
            age = age.replace("-", " to ")

            label = f'{gender}, {age}'
            cv2.rectangle(result_img, (face_box[0], face_box[1]), (face_box[2], face_box[3]), (0, 255, 0), 2)
            cv2.putText(result_img, label, (face_box[0], face_box[1] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2, cv2.LINE_AA)
            rospy.loginfo(f"Detected Gender: {gender}, Age: {age}")

        # Save the image with bounding boxes
        save_path = os.path.join(BASE_PATH, "img/gender_age_detected.jpg")
        cv2.imwrite(save_path, result_img)
        rospy.loginfo(f"Saved image with bounding box to {save_path}")

        # Create a dictionary with the detected information
        detection_info = {
            "gender": gender,
            "age": age
        }

        # Convert the dictionary to a JSON string
        json_message = json.dumps(detection_info)

        # Return the JSON string in the TriggerResponse
        return TriggerResponse(success=True, message=json_message)
        # return TriggerResponse(success=True, message=f"The guest's gender is {gender}, the guest's age is around {age}.")

    def highlight_face(self, net, frame, conf_threshold=0.7):
        frame_copy = frame.copy()
        frame_height = frame_copy.shape[0]
        frame_width = frame_copy.shape[1]

        blob = cv2.dnn.blobFromImage(frame_copy, 1.0, (300, 300), [104, 117, 123], True, False)
        net.setInput(blob)
        detections = net.forward()
        face_boxes = []
        for i in range(detections.shape[2]):
            confidence = detections[0, 0, i, 2]
            if confidence > conf_threshold:
                x1 = int(detections[0, 0, i, 3] * frame_width)
                y1 = int(detections[0, 0, i, 4] * frame_height)
                x2 = int(detections[0, 0, i, 5] * frame_width)
                y2 = int(detections[0, 0, i, 6] * frame_height)
                face_boxes.append([x1, y1, x2, y2])
        return frame_copy, face_boxes

if __name__ == "__main__":
    rospy.init_node('gender_age_detection_service')
    GenderAgeDetectionService()
    rospy.spin()
