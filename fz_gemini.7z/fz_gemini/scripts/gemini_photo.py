#!/home/eevee/catkin_ws/src/fz_gemini/.venv/bin/python3

import time
import os
import socket
import rospy
import subprocess
import json
import difflib

from std_msgs.msg import String, Bool
from std_srvs.srv import Trigger
from PIL import Image

from tts_utils import wait_for_tts, init_tts_subscriber, play_audio
from config import BASE_PATH, API_KEY
from gemini_config import configure_gemini

# Configure the Google Generative AI
generative_model = configure_gemini()

class GeminiPhoto:
    def __init__(self):
        self.image_path = os.path.join(BASE_PATH, "img/captured_image.jpg")
        self.json_file_path = os.path.join(BASE_PATH, "guest_details.json")
        self.names_list_file = os.path.join(BASE_PATH, "fmm_list.json")  # Path to fmm_list.json
        self.user_name = None
        self.names_list = self.load_names_list()  # Load only names
        self.audio_dir = os.path.join(BASE_PATH, "audio")
        self.current_room = os.getenv('CURRENT_ROOM', 'Unknown Room')  # Retrieve the room from the environment variable
        self.pub_speak = rospy.Publisher('speech_to_speak', String, queue_size=10)
        self.pub_resume_rotation = rospy.Publisher('/resume_rotation', Bool, queue_size=10)
        rospy.init_node('gemini_photo_node', anonymous=True)
        rospy.loginfo("Gemini Photo Node Initialized")
        init_tts_subscriber()

    def check_internet_connection(self):
        try:
            socket.create_connection(("8.8.8.8", 53), timeout=3)
            return True
        except OSError:
            return False

    def generate_sentence_gemini(self, image_path, user_name):
        # Include the room information in the description
        if generative_model:
            try:
                img = Image.open(image_path)
                prompt = f"This is an image of a guest named {user_name}, located in {self.current_room}. Include the name and room in the description."
                response = generative_model.generate_content([prompt, img])
                if response and response.text:
                    return response.text
                else:
                    rospy.logwarn("Gemini model returned no response.")
            except Exception as e:
                rospy.logerr(f"Failed to generate description using Gemini: {e}")
        else:
            rospy.logwarn("Gemini model is not configured.")
        return None

    def list_features_gemini(self, description):
        if generative_model:
            try:
                prompt = f"""From the description: '{description}', list the features of the person in this order: 
                            gender, age, wears glasses or not, wears a mask or not, clothing, objects around or near the person.
                            MAKE SURE to include description of glasses and masks, if they are not wearing any, explicitly say so.
                            Do it in json format since there can be multiple clothing and objects.
                            Take note for glasses and mask, make the key name to be wears_glasses and wears_mask."""
                response = generative_model.generate_content([prompt])
                if response and response.text:
                    json_str = response.text.strip().strip("```json").strip("```").strip()
                    return json_str
                else:
                    rospy.logwarn("Gemini model returned no response for listing features.")
            except Exception as e:
                rospy.logerr(f"Failed to generate feature list using Gemini: {e}")
        else:
            rospy.logwarn("Gemini model is not configured.")
        return None
    
    def load_names_list(self):
        """Load only the names from the fmm_list.json file."""
        try:
            with open(self.names_list_file, 'r') as file:
                data = json.load(file)
                names = data.get('names', [])  # Load only the names, ignoring rooms
                return names
        except Exception as e:
            rospy.logerr(f"Failed to load names list from {self.names_list_file}: {e}")
            return []

    def extract_name_gemini(self, sentence, retries=0, max_retries=3):
        """Extract name from the sentence using the Gemini model."""
        if generative_model:
            try:
                prompt = f"Extract the name from this sentence: '{sentence}'. Only return the name."
                response = generative_model.generate_content([prompt])
                if response and response.text:
                    extracted_name = response.text.strip()

                    # Check if the extracted name is in the names list
                    if extracted_name in self.names_list:
                        return extracted_name
                    else:
                        # Find the nearest match using difflib
                        closest_match = difflib.get_close_matches(extracted_name, self.names_list, n=1, cutoff=0.6)
                        if closest_match:
                            rospy.loginfo(f"Nearest match found: {closest_match[0]}")
                            return closest_match[0]
                        else:
                            # Log info and increment retries if no match is found
                            rospy.loginfo(f"No close match found, repeating the asking process. Retry {retries + 1}/{max_retries}")
                            self.pub_speak.publish("Your name is not in the list, asking for name again.")
                            wait_for_tts()
                            return self.ask_name_again(retries=retries + 1, max_retries=max_retries)

                else:
                    rospy.logwarn("Gemini model returned no response for name extraction.")
                    return self.ask_name_again(retries=retries + 1, max_retries=max_retries)

            except Exception as e:
                rospy.logerr(f"Failed to extract name using Gemini: {e}")
                return self.ask_name_again(retries=retries + 1, max_retries=max_retries)
        else:
            rospy.logwarn("Gemini model is not configured.")
            return self.ask_name_again(retries=retries + 1, max_retries=max_retries)

    def extract_name_offline(self, sentence):
        """Extract name by directly searching within the speech-recognized string."""
        sentence_lower = sentence.lower()

        # Check if any name from the names list is present in the sentence
        for name in self.names_list:
            if name.lower() in sentence_lower:
                rospy.loginfo(f"Exact match found: {name}")
                return name

        # If no exact match, use difflib to find the closest match
        closest_match = difflib.get_close_matches(sentence_lower, [name.lower() for name in self.names_list], n=1, cutoff=0.6)
        if closest_match:
            matched_name = closest_match[0].title()  # Title case the matched name
            rospy.loginfo(f"Nearest match found: {matched_name}")
            return matched_name

        # If no match is found, ask for the name again
        rospy.loginfo("No match found, repeating the asking process.")
        self.pub_speak.publish("Your name is not in the list, asking for name again.")
        wait_for_tts()
        return self.ask_name_again()

    def ask_name_again(self, last_heard_name=None, retries=0, max_retries=3):
        """Function to repeat the name asking process."""
        if retries >= max_retries:
            # If retries exceed the limit, use the last heard name instead of "Unknown"
            if last_heard_name:
                rospy.loginfo(f"Bot: Max retries reached. Proceeding with the last heard name: {last_heard_name}.")
                self.pub_speak.publish(f"Max retries reached. Proceeding with the name: {last_heard_name}.")
                wait_for_tts()
                return last_heard_name
            else:
                rospy.loginfo("Bot: Max retries reached. Setting name to 'Unknown'.")
                self.pub_speak.publish("Max retries reached. Setting name to 'Unknown'.")
                wait_for_tts()
                return "Unknown"

        rospy.loginfo(f"Bot: Asking for the name again. Retry {retries + 1}/{max_retries}")
        play_audio("ask_name.wav", BASE_PATH)
        rospy.wait_for_service('start_speech_recognition')
        speech_recognition = rospy.ServiceProxy('start_speech_recognition', Trigger)
        response = speech_recognition()

        if response.success:
            full_sentence = response.message
            rospy.loginfo(f"Bot: Guest said: {full_sentence}")

            # Skip any further checks if the name is "Unknown"
            if "unknown".lower() in full_sentence.lower():
                rospy.loginfo("Bot: Name is 'Unknown', skipping further checks.")
                return "Unknown"

            # Choose method based on internet availability
            has_internet = self.check_internet_connection()
            if has_internet:
                # Pass retries and last_heard_name to extract_name_gemini
                name = self.extract_name_gemini(full_sentence, retries=retries, max_retries=max_retries)
            else:
                name = self.extract_name_offline(full_sentence)

            # If the name is "Unknown", skip further checks
            if name == "Unknown":
                rospy.loginfo("Bot: The name was not recognized after multiple attempts. Setting name to 'Unknown'.")
                return "Unknown"

            if name:
                # Check if the name is in the names list
                if name not in self.names_list:
                    rospy.loginfo(f"Bot: Name {name} is not in the list.")
                    self.pub_speak.publish("Your name is not in the list, asking for name again.")
                    wait_for_tts()
                    return self.ask_name_again(last_heard_name=name, retries=retries + 1, max_retries=max_retries)
                return name
            else:
                return self.ask_name_again(last_heard_name=full_sentence, retries=retries + 1, max_retries=max_retries)
        else:
            rospy.loginfo("Bot: I didn't catch that. Please try again.")
            play_audio("try_again.wav", BASE_PATH)
            return self.ask_name_again(last_heard_name=last_heard_name, retries=retries + 1, max_retries=max_retries)


    def generate_sentence_moondream(self, image_path, user_name):
        # Ensure that the image path is correctly passed as a parameter to the Moondream service
        if not os.path.exists(image_path):
            rospy.logerr(f"Image path does not exist: {image_path}")
            return None, None

        rospy.set_param('~image_path', image_path)
        rospy.set_param('~user_name', user_name)

        rospy.wait_for_service('moondream_generate_description')
        moondream_service = rospy.ServiceProxy('moondream_generate_description', Trigger)

        try:
            # Initialize features dictionary
            features = {
                "Guest ID": int(os.environ.get('GUEST_ID', 1)),
                "Name": user_name,
                "Description": "",
                "Gender": "",
                "Age": "Unknown",  # Age extraction not implemented
                "Wears Glasses": "Unknown",
                "Wears Mask": "Unknown",
                "Clothing": "Unknown",
                "Nearby Objects": "Unknown"
            }

            # First prompt: Get the gender of the person
            try:
                rospy.set_param('~prompt', "What is the gender of the person in the image? Reply only 'male' or 'female'.")
                response_gender = moondream_service()
                if not response_gender.success:
                    rospy.logwarn("Moondream service failed for gender: " + response_gender.message)
                    raise rospy.ServiceException("Moondream failed to get gender.")
                gender = response_gender.message.strip()
                features["Gender"] = gender
            except rospy.ServiceException as e:
                rospy.logerr(f"Error fetching gender: {str(e)}")
                return None, None

            # Second prompt: Get the person's attire
            try:
                rospy.set_param('~prompt', "What is the person's attire?")
                response_attire = moondream_service()
                if not response_attire.success:
                    rospy.logwarn("Moondream service failed for attire: " + response_attire.message)
                    raise rospy.ServiceException("Moondream failed to get attire.")
                attire = response_attire.message.strip()
                features["Clothing"] = attire
            except rospy.ServiceException as e:
                rospy.logerr(f"Error fetching attire: {str(e)}")
                return None, None

            # Third prompt: Check if the person is wearing glasses
            try:
                rospy.set_param('~prompt', "Is the person wearing glasses? Answer 'yes' or 'no'.")
                response_glasses = moondream_service()
                if not response_glasses.success:
                    rospy.logwarn("Moondream service failed for glasses: " + response_glasses.message)
                    raise rospy.ServiceException("Moondream failed to get glasses information.")
                glasses = "yes" if response_glasses.message.strip().lower() == "yes" else "no"
                features["Wears Glasses"] = glasses
            except rospy.ServiceException as e:
                rospy.logerr(f"Error fetching glasses information: {str(e)}")
                return None, None

            # Fourth prompt: Check if the person is wearing a mask
            try:
                rospy.set_param('~prompt', "Is the person wearing a mask? Answer 'yes' or 'no'.")
                response_mask = moondream_service()
                if not response_mask.success:
                    rospy.logwarn("Moondream service failed for mask: " + response_mask.message)
                    raise rospy.ServiceException("Moondream failed to get mask information.")
                mask = "yes" if response_mask.message.strip().lower() == "yes" else "no"
                features["Wears Mask"] = mask
            except rospy.ServiceException as e:
                rospy.logerr(f"Error fetching mask information: {str(e)}")
                return None, None

            # Fifth prompt: Where and what is the person doing?
            try:
                rospy.set_param('~prompt', "Where and what is the person doing?")
                response_activity = moondream_service()
                if not response_activity.success:
                    rospy.logwarn("Moondream service failed for activity: " + response_activity.message)
                    raise rospy.ServiceException("Moondream failed to get activity information.")
                activity = response_activity.message.strip()
                features["Nearby Objects"] = activity
            except rospy.ServiceException as e:
                rospy.logerr(f"Error fetching activity information: {str(e)}")
                return None, None

            # Combine the results into a final description
            description = (f"Guest {features['Guest ID']}, {user_name}'s gender is {gender}. {attire}. "
                        f"The person is {('not ' if glasses == 'no' else '')}wearing glasses and "
                        f"{('not ' if mask == 'no' else '')}wearing a mask. "
                        f"{activity}")

            # Store the description in the features dictionary
            features["Description"] = description

            return description, json.dumps(features, indent=4)
        except rospy.ServiceException as e:
            rospy.logerr(f"Moondream service call failed: {str(e)}")
            return None, None
        except Exception as e:
            rospy.logerr(f"Unexpected error: {str(e)}")
            return None, None

    def save_guest_details_json(self, name, description, features_json):
        try:
            features = json.loads(features_json)
        except json.JSONDecodeError:
            rospy.logerr("Failed to parse features JSON.")
            features = {}

        guest_id = int(os.environ.get('GUEST_ID', 0))

        guest_details = {
            'Guest ID': guest_id,
            'Name': name,
            'Description': description,
            'Gender': features.get('gender', 'Unknown'),
            'Age': features.get('age', 'Unknown'),
            'Wears Glasses': features.get('wears_glasses', 'Unknown'),
            'Wears Mask': features.get('wears_mask', 'Unknown'),
            'Clothing': features.get('clothing', 'Unknown') if isinstance(features.get('clothing'), str) else ", ".join(features.get('clothing', ['Unknown'])),
            'Nearby Objects': features.get('objects', 'Unknown') if isinstance(features.get('objects'), str) else ", ".join(features.get('objects', ['Unknown']))
        }

        if os.path.exists(self.json_file_path):
            with open(self.json_file_path, 'r') as file:
                try:
                    data = json.load(file)
                except json.JSONDecodeError:
                    data = []
        else:
            data = []

        data.append(guest_details)

        with open(self.json_file_path, 'w') as file:
            json.dump(data, file, indent=4)
        
        rospy.loginfo(f"Guest details saved to JSON: {guest_details}")

    def run(self):
        # Placeholder for the capture image functionality
        rospy.wait_for_service('capture_image')
        capture_image = rospy.ServiceProxy('capture_image', Trigger)

        time.sleep(1)

        has_internet = self.check_internet_connection()

        if not has_internet:
            rospy.logwarn("No internet connection. Switching to offline local models.")
            play_audio("offline_switch.wav", BASE_PATH)

        while True:
            rospy.loginfo("Bot: Preparing to take a photo, starting countdown.")
            play_audio("preparing_to_take_photo.wav", BASE_PATH)
            rospy.loginfo("Bot: Taking a photo in five, four, three, two, one.")
            play_audio("taking_photo_countdown.wav", BASE_PATH)

            rospy.loginfo("Attempting to call the capture_image service...")
            response_img = capture_image()

            if not response_img.success:
                rospy.logerr("Failed to capture image: " + response_img.message)
                play_audio("photo_not_captured.wav", BASE_PATH)
                retry = input("Camera is not available. Do you want to try again? (y/n): ").strip().lower()
                if retry != 'y':
                    return
            else:
                rospy.loginfo("Image captured successfully.")
                play_audio("photo_captured.wav", BASE_PATH)
                break

        # Get the guest's name
        while not self.user_name:
            rospy.loginfo("Bot: Please provide me your name.")
            play_audio("ask_name.wav", BASE_PATH)

            rospy.wait_for_service('start_speech_recognition')
            speech_recognition = rospy.ServiceProxy('start_speech_recognition', Trigger)
            response = speech_recognition()
            while not response.success and not rospy.is_shutdown():
                response = speech_recognition()

            if response.success:
                full_sentence = response.message
                rospy.loginfo(f"Bot: Guest said: {full_sentence}")

                # Skip further checks if the recognized name is "Unknown"
                if full_sentence.lower() == "unknown":
                    self.user_name = "Unknown"
                    rospy.loginfo("Bot: Name not recognized after retries. Proceeding with 'Unknown'.")
                    break

                # Choose method based on internet availability
                if has_internet:
                    name = self.extract_name_gemini(full_sentence)
                else:
                    name = self.extract_name_offline(full_sentence)

                # If name is "Unknown", skip the retry and proceed
                if name == "Unknown":
                    self.user_name = "Unknown"
                    rospy.loginfo("Bot: Name not recognized, proceeding with 'Unknown'.")
                    break

                if name:
                    self.user_name = name
                    rospy.loginfo(f"Bot: Nice to meet you, {self.user_name}!")
                    play_audio("name_acknowledged.wav", BASE_PATH)
                    self.pub_speak.publish(f"{self.user_name}")
                    wait_for_tts()
                else:
                    rospy.loginfo("Bot: I couldn't understand the name. Please try again.")
                    play_audio("try_again.wav", BASE_PATH)
            else:
                rospy.loginfo("Bot: I didn't catch that. Please try again.")
                play_audio("try_again.wav", BASE_PATH)

        # Continue with description generation
        if has_internet:
            description = self.generate_sentence_gemini(self.image_path, self.user_name)
            features_json = self.list_features_gemini(description) if description else None
        else:
            rospy.loginfo("Attempting to call Moondream service")
            description, features_json = self.generate_sentence_moondream(self.image_path, self.user_name)

        if description and features_json:
            rospy.loginfo(f"Generated description: {description}")
            rospy.loginfo(f"Extracted features: {features_json}")
            # self.pub_speak.publish(description)
            # wait_for_tts()
            self.save_guest_details_json(self.user_name, description, features_json)
        else:
            rospy.logwarn("Description generation failed.")

        # Publish the resume signal to /resume_rotation
        self.pub_resume_rotation.publish(True)
        rospy.loginfo("Published resume rotation signal.")

if __name__ == "__main__":
    try:
        gemini_photo = GeminiPhoto()
        gemini_photo.run()
    except rospy.ROSInterruptException:
        pass
