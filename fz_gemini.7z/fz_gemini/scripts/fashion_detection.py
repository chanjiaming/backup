#!/home/eevee/catkin_ws/src/fz_gemini/.venv/bin/python3

import rospy
from std_srvs.srv import Trigger, TriggerResponse
import cv2
import os
import json
from ultralytics import YOLO

from config import BASE_PATH

class FashionDetectionService:
    def __init__(self):
        # Load YOLO model
        self.yolo_model = YOLO(os.path.join(BASE_PATH, 'fashion_model/fashion_best.pt'))

        # Initialize ROS service
        rospy.Service('fashion_detection', Trigger, self.handle_detection)
        rospy.loginfo("Fashion Detection Service is ready.")

    def handle_detection(self, req):
        image_path = os.path.join(BASE_PATH, "img/captured_image.jpg")
        detected_objects = self.process_image(image_path)

        if detected_objects:
            # Create a dictionary with the detected information
            detection_info = {"clothing": detected_objects}

            # Convert the dictionary to a JSON string
            json_message = json.dumps(detection_info)

            return TriggerResponse(success=True, message=json_message)
        else:
            detection_info = {"clothing": {}}
            json_message = json.dumps(detection_info)
            return TriggerResponse(success=False, message=json_message)

        # if detected_objects:
        #     detected_objects_str = ", ".join([f"{count} {item}(s)" for item, count in detected_objects.items()])
        #     return TriggerResponse(success=True, message=f"The guest's attire may include {detected_objects_str}.")
        # else:
        #     return TriggerResponse(success=False, message="No objects detected.")

    def process_image(self, image_path):
        # Perform detection using the YOLO model
        result = self.yolo_model.predict(source=image_path, conf=0.5)
        
        objects = {}
        for res in result:
            for bbox in res.boxes:
                cls = int(bbox.cls[0])
                label = self.yolo_model.names[cls]
                if label in objects:
                    objects[label] += 1
                else:
                    objects[label] = 1
        
        # Optionally, save the image with bounding boxes
        result_img = result[0].plot()  # Plot the result
        save_path = os.path.join(BASE_PATH, "img/fashion_detected.jpg")
        cv2.imwrite(save_path, result_img)
        rospy.loginfo(f"Saved image with bounding box to {save_path}")

        return objects

if __name__ == "__main__":
    rospy.init_node('fashion_detection_service')
    FashionDetectionService()
    rospy.spin()