#!/home/eevee/catkin_ws/src/fz_gemini/.venv/bin/python3

import rospy
import subprocess
import time
import os
import json
import socket

from tts_utils import play_audio
from config import BASE_PATH

json_file_path = os.path.join(BASE_PATH, "guest_details.json")

def check_internet_connection():
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=3)
        return True
    except OSError:
        return False

def clear_json_file():
    """
    Function to clear the guest details JSON file at the start of the session.
    """
    with open(json_file_path, 'w') as file:
        json.dump([], file)  # Write an empty list to clear the file
    rospy.loginfo("Cleared guest details JSON file.")

def detect_guest():
    """
    Function to simulate guest detection.
    Press Enter to simulate a new guest detection, or 'c' to stop and proceed to comparison.
    """
    while True:
        user_input = input("Press Enter to simulate guest detection or 'c' to stop detecting and compare: ").strip().lower()
        if user_input == '':
            return True
        elif user_input == 'c':
            return False

def trigger_gemini_photo(guest_id):
    """
    Function to trigger the gemini_photo.py script.
    This function will call the script using subprocess.
    Passes the guest ID as an environment variable.
    """
    gemini_photo_path = os.path.join(BASE_PATH, "scripts/gemini_photo.py")
    rospy.loginfo(f"Guest {guest_id} detected! Triggering gemini_photo.py...")

    play_audio("guest_detected.wav", BASE_PATH)

    env = os.environ.copy()
    env['GUEST_ID'] = str(guest_id)
    subprocess.run([gemini_photo_path], env=env)
    rospy.sleep(2)  # Add a 2-second pause after triggering the script

def move_to_operator():
    """
    Placeholder function to simulate moving to the operator.
    """
    rospy.loginfo("Stopping guest detection. Moving to the operator...")
    print("Simulating the robot moving to the operator...")
    rospy.sleep(2)  # Add a 2-second pause

def run_comparison():
    """
    Function to run the appropriate comparison script (online or offline).
    """
    has_internet = check_internet_connection()
    
    if has_internet:
        compare_script_path = os.path.join(BASE_PATH, "scripts/gemini_compare.py")
        rospy.loginfo("Running online guest comparison...")
    else:
        compare_script_path = os.path.join(BASE_PATH, "scripts/offline_compare.py")
        rospy.logwarn("No internet connection. Running offline guest comparison...")

    subprocess.run([compare_script_path])
    rospy.sleep(2)  # Add a 2-second pause after running the comparison

def launch_in_new_terminal(command):
    """
    Launch a command in a new terminal window.
    """
    subprocess.Popen(['gnome-terminal', '--', 'bash', '-c', command])

def main():
    """
    Main function to simulate guest detection, trigger photo capturing, and compare guests.
    """
    rospy.init_node('guest_detection_simulation_node', anonymous=True)
    launch_file = os.path.join(BASE_PATH, "launch/general.launch")
    general_launch_process = subprocess.Popen(["roslaunch", launch_file])
    rospy.loginfo("Launched general.launch")

    # Launch the general.launch file in a new terminal, excluding the TTS node
    # launch_file = os.path.join(BASE_PATH, "launch/general_no_tts.launch")
    # launch_in_new_terminal(f"roslaunch {launch_file}")
    # rospy.loginfo("Launched general_without_tts.launch in a new terminal")

    # # Launch the TTS node in a separate terminal
    # tts_node_command = "rosrun gemini_speech text_to_speech.py"
    # launch_in_new_terminal(tts_node_command)
    # rospy.loginfo("Launched TTS node in a separate terminal")

    # Clear the JSON file at the start of the session
    clear_json_file()
    guest_count = 0
    try:
        while not rospy.is_shutdown():
            if not detect_guest():  # Check if the cancel option was chosen
                break
            guest_count += 1
            trigger_gemini_photo(guest_count)
            rospy.loginfo(f"Guest {guest_count} detected.")
            rospy.sleep(5)  # Adding a sleep time between each guest detection

        move_to_operator()
        run_comparison()  # Decide which comparison to run based on internet connection

    finally:
        rospy.loginfo("Terminating")
        if general_launch_process:
            general_launch_process.terminate()
            general_launch_process.wait()


if __name__ == "__main__":
    main()