#!/home/eevee/catkin_ws/src/fz_gemini/.venv/bin/python3

import json
import os
import rospy
from std_msgs.msg import String

from tts_utils import wait_for_tts, init_tts_subscriber
from config import BASE_PATH
from gemini_config import configure_gemini  # Import the configuration

# Configure the Google Generative AI
generative_model = configure_gemini()

json_file_path = os.path.join(BASE_PATH, "guest_details.json")  # Path to the JSON file

def load_guest_details():
    try:
        with open(json_file_path, 'r') as file:
            return json.load(file)
    except json.JSONDecodeError as e:
        rospy.logerr("Error reading JSON file: %s", e)
        return []

def remove_overlap(previous_text, current_text):
    """
    Remove the overlap of repeated words from the current text that appear at the end of previous text.
    """
    # Split the texts into words
    previous_words = previous_text.split()
    current_words = current_text.split()

    # Find the longest overlap
    for i in range(len(current_words)):
        if previous_words[-i:] == current_words[:i]:
            return " ".join(current_words[i:])
    
    return current_text  # No overlap found, return the current text as is

def compare_guests(guest_list):
    if not guest_list:
        rospy.logwarn("No guests to compare.")
        return "No guests to compare."

    # Define the initial prompt for the model
    base_prompt = """You will receive guest details. For each guest, identify their Gender (this is mandatory) and exactly 2 unique features ONLY from the categories Age, Wears Glasses, Wears Mask, and Clothing, NOT other classes, keep in mind that the Age category is the LOWEST priority in this case.
                     Please ensure that the unique features are ONLY from these categories and are TRULY UNIQUE compared to all other guests. Check if the feature is not shared by any other guest before identifying it as unique.
                     Once done, compare the nearby objects for each guest and identify the unique objects. Use the Description field to understand and explain how the guest interacts with these objects. For example, describe whether the guest is using, holding, sitting on, or positioned near the object.
                     For example, you should output something like this:
                     Guest 1, Alex's gender is male. He is the only one wearing glasses and is the only one wearing a blue shirt. Alex has a laptop and fan nearby.
                     Guest 2, Grace's gender is female. She is the only one wearing a yellow dress and the only one wearing a red hat. Grace is sitting on the sofa and there is a shelf nearby.
                     Please follow this format exactly and remove the indicators in parenthesis. Here are the guest details:\n"""
    
    # Append guest details to the prompt
    for guest in guest_list:
        base_prompt += (
            f"Guest ID: {guest['Guest ID']}, Name: {guest['Name']}, "
            f"Gender: {guest['Gender']}, Age: {guest['Age']}, "
            f"Wears Glasses: {guest['Wears Glasses']}, Wears Mask: {guest['Wears Mask']}, "
            f"Clothing: {guest['Clothing']}, Nearby Objects: {guest['Nearby Objects']}\n"
            f"Description: {guest['Description']}\n"
        )

    full_response = ""
    follow_up_prompt = base_prompt
    last_response_text = None  # To store the last response text

    while True:
        try:
            # Send the prompt to the Generative AI model
            if generative_model:
                response = generative_model.generate_content([follow_up_prompt])

                if response and hasattr(response, 'text'):
                    response_text = response.text.strip()
                    rospy.loginfo(f"Generated Response: {response_text}")
                    
                    # If the response is the same as the last one, break the loop
                    if response_text == last_response_text:
                        rospy.loginfo("No new content generated; assuming completion.")
                        break
                    
                    # Remove overlap before adding to full_response
                    if last_response_text:
                        response_text = remove_overlap(last_response_text, response_text)
                    
                    last_response_text = response_text
                    full_response += " " + response_text

                    # Check if the response seems to be truncated
                    if response_text.endswith(('.', '!', '?')):
                        break  # Assume completion if the response ends properly

                    # Prepare the follow-up prompt to ask for continuation
                    follow_up_prompt = f"{base_prompt}\n\nPlease continue from where you left off only by starting where it was cut off:\n{response_text}"

                else:
                    rospy.logwarn("No valid response text found in the model's output.")
                    break
            else:
                rospy.logwarn("Generative model is not configured.")
                break
        except Exception as e:
            # Handle specific known errors
            if "safety_ratings" in str(e):
                rospy.logwarn("Response blocked due to safety ratings, skipping this request.")
                return "Comparison was blocked due to safety concerns."
            else:
                rospy.logerr(f"Failed to compare guests using Gemini: {e}")
                break

    return full_response.strip()

def main():
    rospy.init_node('guest_comparison_node', anonymous=True)
    pub_speak = rospy.Publisher('speech_to_speak', String, queue_size=10)
    init_tts_subscriber()

    guest_list = load_guest_details()
    comparison_result = compare_guests(guest_list)

    if comparison_result == "No guests to compare.":
        rospy.loginfo("No guests to compare, exiting.")
        return

    # Publish the comparison result to the TTS topic
    pub_speak.publish(comparison_result)
    wait_for_tts()

if __name__ == "__main__":
    main()
