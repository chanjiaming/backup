#!/usr/bin/python3
import sys
sys.path.insert(0, '/home/eevee/catkin_ws/src/moondream_pkg/moondream_venv/lib/python3.8/site-packages')

import os
import rospy
from std_srvs.srv import Trigger, TriggerResponse
import torch
from moondream import detect_device, LATEST_REVISION, Moondream
from threading import Thread
from transformers import TextIteratorStreamer, AutoTokenizer
from PIL import Image, ImageDraw
from torchvision.transforms.v2 import Resize
import re

# Initialize the ROS node
rospy.init_node('moondream_service_node')

# Detect device and set dtype
use_cpu = False
if use_cpu:
    device = torch.device("cpu")
    dtype = torch.float32
else:
    device, dtype = detect_device()
    if device != torch.device("cpu"):
        rospy.loginfo("Using device: {}".format(device))
        rospy.loginfo("Set use_cpu = true if CUDA is problematic")

# Load model and tokenizer
model_id = "vikhyatk/moondream2"
tokenizer = AutoTokenizer.from_pretrained(model_id, revision=LATEST_REVISION)
moondream = Moondream.from_pretrained(
    model_id, revision=LATEST_REVISION, torch_dtype=dtype
).to(device=device)
moondream.eval()

def extract_floats(text):
    pattern = r"\[\s*(-?\d+\.\d+)\s*,\s*(-?\d+\.\d+)\s*,\s*(-?\d+\.\d+)\s*,\s*(-?\d+\.\d+)\s*\]"
    match = re.search(pattern, text)
    if match:
        return [float(num) for num in match.groups()]
    return None

def extract_bbox(text):
    bbox = None
    if extract_floats(text) is not None:
        x1, y1, x2, y2 = extract_floats(text)
        bbox = (x1, y1, x2, y2)
    return bbox

def process_answer(img, answer):
    if extract_bbox(answer) is not None:
        x1, y1, x2, y2 = extract_bbox(answer)
        draw_image = Resize(768)(img)
        width, height = draw_image.size
        x1, x2 = int(x1 * width), int(x2 * width)
        y1, y2 = int(y1 * height), int(y2 * height)
        bbox = (x1, y1, x2, y2)
        ImageDraw.Draw(draw_image).rectangle(bbox, outline="red", width=3)
        draw_image.show()  # Display the image with the bounding box

def answer_question(img, prompt):
    image_embeds = moondream.encode_image(img)
    streamer = TextIteratorStreamer(tokenizer, skip_special_tokens=True)
    thread = Thread(
        target=moondream.answer_question,
        kwargs={
            "image_embeds": image_embeds,
            "question": prompt,
            "tokenizer": tokenizer,
            "streamer": streamer,
        },
    )
    thread.start()

    buffer = ""
    for new_text in streamer:
        buffer += new_text

    return buffer.strip()

def generate_description(req):
    try:
        # Retrieve parameters
        image_path = rospy.get_param('~image_path', '')
        user_name = rospy.get_param('~user_name', 'Guest')
        
        # Validate inputs
        if not image_path:
            return TriggerResponse(success=False, message="Image path is not provided.")
        
        if not os.path.exists(image_path):
            return TriggerResponse(success=False, message=f"Image path does not exist: {image_path}")
        
        # Load the image from the provided path
        img = Image.open(image_path)

        # Generate description
        prompt = f"Describe the image for {user_name}"
        description = answer_question(img, prompt)

        return TriggerResponse(success=True, message=description)
    except Exception as e:
        rospy.logerr("Error in processing: {}".format(str(e)))
        return TriggerResponse(success=False, message=str(e))


# Define the service
service = rospy.Service('moondream_generate_description', Trigger, generate_description)

# Keep the node alive
rospy.loginfo("Moondream service node is ready.")
rospy.spin()