#!/home/eevee/catkin_ws/src/fz_gemini/.venv/bin/python3

import rospy
from std_msgs.msg import String
from gtts import gTTS
import pygame
import os

def text_to_speech_gtts(text):
    try:
        tts = gTTS(text=text, lang='en')
        audio_file = "response.mp3"
        pygame.mixer.init()

        if os.path.exists(audio_file):
            pygame.mixer.music.unload()
            os.remove(audio_file)

        tts.save(audio_file)
        pygame.mixer.music.load(audio_file)
        pygame.mixer.music.play()

        while pygame.mixer.music.get_busy():
            rospy.sleep(0.1)

        pygame.mixer.quit()

        rospy.loginfo("TTS Node: Finished speaking with gTTS.")
        pub_finished.publish("finished")
        return True

    except Exception as e:
        rospy.logerr(f"gTTS failed with error: {e}")
        return False

def callback(data):
    rospy.loginfo(f"TTS Node: Received - {data.data}")
    text_to_speech_gtts(data.data)

def main():
    global pub_finished
    
    rospy.init_node('text_to_speech_node', anonymous=True)
    rospy.Subscriber('speech_to_speak', String, callback)
    pub_finished = rospy.Publisher('tts_finished', String, queue_size=10)

    rospy.spin()

if __name__ == "__main__":
    main()
