#!/home/eevee/catkin_ws/src/fz_gemini/.venv/bin/python3

import time
import os
import rospy
from std_msgs.msg import String
from std_srvs.srv import Trigger
from PIL import Image
import google.generativeai as genai
from tts_utils import wait_for_tts, init_tts_subscriber

# Configure the Google Generative AI
genai.configure(api_key="AIzaSyAojLMeaYC_9CABMf6QHZv5gGV4mWws4ko")

# Create the Generative AI model
generation_config = {
    "temperature": 0.5,
    "top_p": 0.95,
    "top_k": 64,
    "max_output_tokens": 100,
    "response_mime_type": "text/plain",
}

safety_settings = [
    {
        "category": "HARM_CATEGORY_HARASSMENT",
        "threshold": "BLOCK_NONE",
    },
    {
        "category": "HARM_CATEGORY_HATE_SPEECH",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE",
    },
    {
        "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE",
    },
    {
        "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE",
    },
]

generative_model = genai.GenerativeModel(
    model_name="gemini-1.5-flash",
    safety_settings=safety_settings,
    generation_config=generation_config,
    system_instruction="You will be receiving an image of a person which is the guest. I want you to describe the person by stating his/her gender and age. Then, describe the person's attire, especially the color of their clothing. Then, provide the guest's location or any other notable things surrounding them. Make the response short to around 20 words",
)

images_path = "/home/orin_nano/overlay_ws/src/gemini_guest_desc/img"
user_name = None  # Store the user's name globally

def generate_sentence_gemini(image_path, user_name):
    img_path = os.path.join(images_path, image_path)
    img = Image.open(img_path)
    prompt = f"This is an image of a guest named {user_name}."
    response = generative_model.generate_content([prompt, img])
    return response.text

def main():
    global user_name, pub_speak

    rospy.init_node('guest_description_node', anonymous=True)
    pub_speak = rospy.Publisher('speech_to_speak', String, queue_size=10)
    init_tts_subscriber()  # Initialize TTS subscriber from the utility module

    rospy.wait_for_service('start_speech_recognition')
    speech_recognition = rospy.ServiceProxy('start_speech_recognition', Trigger)

    rospy.loginfo("Bot: Please provide the name of the image file you want to analyze (e.g., 'image.jpg').")
    image_name = input("You: ")
    # Ensures that the TTS node and ROS communication are ready before the first message is published, leading to consistent behavior.
    # time.sleep(1)

    rospy.loginfo("Bot: Let me analyze the image and describe it to you.")
    pub_speak.publish("Let me analyze the image and describe it to you.")

    wait_for_tts()  # Wait for TTS to finish

    # Ask for the name
    rospy.loginfo("Bot: Hello, what is your name?")
    pub_speak.publish("Hello, what is your name?")

    wait_for_tts()  # Wait for TTS to finish

    # Trigger speech recognition service and wait for the response
    response = speech_recognition()
    while not response.success and not rospy.is_shutdown():
        wait_for_tts()  # Wait for TTS to finish (retrying)

        response = speech_recognition()

    if response.success:
        user_name = response.message
        rospy.loginfo(f"Bot: Nice to meet you, {user_name}!")
        pub_speak.publish(f"Nice to meet you, {user_name}!")

        wait_for_tts()  # Wait for TTS to finish
    else:
        rospy.loginfo("Bot: I didn't catch that. Please try again.")
        pub_speak.publish("I didn't catch that. Please try again.")
        return

    # Proceed with generating the description
    description = generate_sentence_gemini(image_name, user_name)
    response_text = f"The guest's name is {user_name}. {description}"
    
    rospy.loginfo(response_text)
    pub_speak.publish(response_text)

    wait_for_tts()  # Wait for TTS to finish

if __name__ == "__main__":
    main()
