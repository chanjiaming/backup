#!/home/eevee/catkin_ws/src/fz_gemini/.venv/bin/python3

import rospy
import pygame
import os
from std_msgs.msg import String
from gtts import gTTS
from TTS.api import TTS

from config import BASE_PATH

def text_to_speech_gtts(text):
    try:
        audio_file = os.path.join(BASE_PATH, "scripts/response.mp3")
        tts = gTTS(text=text, lang='en')
        pygame.mixer.init()

        if os.path.exists(audio_file):
            pygame.mixer.music.unload()
            os.remove(audio_file)

        tts.save(audio_file)
        pygame.mixer.music.load(audio_file)
        pygame.mixer.music.play()

        while pygame.mixer.music.get_busy():
            rospy.sleep(0.1)

        pygame.mixer.quit()

        rospy.loginfo("TTS Node: Finished speaking with gTTS.")
        pub_finished.publish("finished")
        return True

    except Exception as e:
        rospy.logerr(f"gTTS failed with error: {e}")
        return False

def text_to_speech_coqui(text):
    try:
        tts = TTS(model_name="tts_models/en/ljspeech/glow-tts")
        audio_file = os.path.join(BASE_PATH, "scripts/coqui_response.wav")
        tts.tts_to_file(text=text, file_path=audio_file)

        pygame.mixer.init()
        pygame.mixer.music.load(audio_file)
        pygame.mixer.music.play()

        while pygame.mixer.music.get_busy():
            rospy.sleep(0.1)

        pygame.mixer.quit()

        rospy.loginfo("TTS Node: Finished speaking with Coqui TTS.")
        pub_finished.publish("finished")

    except Exception as e:
        rospy.logerr(f"Coqui TTS failed with error: {e}")

def callback(data):
    rospy.loginfo(f"TTS Node: Received - {data.data}")
    if not text_to_speech_gtts(data.data):
        rospy.loginfo("Falling back to local Coqui TTS model.")
        text_to_speech_coqui(data.data)

def main():
    global pub_finished
    
    rospy.init_node('text_to_speech_node')
    rospy.Subscriber('speech_to_speak', String, callback)
    pub_finished = rospy.Publisher('tts_finished', String, queue_size=10)

    rospy.spin()

if __name__ == "__main__":
    main()