#!/home/eevee/catkin_ws/src/fz_gemini/.venv/bin/python3

import rospy
import os
import time
import pygame  # For playing audio files
from std_msgs.msg import String

# Global variable to track TTS status
tts_done = False

def tts_finished_callback(data):
    global tts_done
    rospy.loginfo("TTS finished.")
    tts_done = True

def wait_for_tts():
    global tts_done
    # Wait for TTS to finish
    while not tts_done and not rospy.is_shutdown():
        rospy.sleep(0.1)
    tts_done = False  # Reset for the next TTS

def init_tts_subscriber():
    rospy.Subscriber('tts_finished', String, tts_finished_callback)

def init_mixer():
    """Initialize pygame mixer with error handling."""
    try:
        if not pygame.mixer.get_init():  # Check if the mixer is already initialized
            pygame.mixer.init()
            rospy.loginfo("Pygame mixer initialized.")
    except pygame.error as e:
        rospy.logerr(f"Failed to initialize pygame mixer: {e}")
        # Try reinitializing after a small delay
        rospy.sleep(1)
        pygame.mixer.quit()
        pygame.mixer.init()

def play_audio(audio_file, base_path):
    init_mixer()  # Ensure mixer is initialized before playing
    file_path = os.path.join(base_path, 'audio', audio_file)
    if os.path.exists(file_path):
        rospy.loginfo(f"Playing audio: {file_path}")
        try:
            pygame.mixer.music.load(file_path)
            pygame.mixer.music.play()
            while pygame.mixer.music.get_busy():  # Wait for the sound to finish
                time.sleep(0.1)
        except pygame.error as e:
            rospy.logerr(f"Error playing audio: {e}")
    else:
        rospy.logwarn(f"Audio file {file_path} not found.")