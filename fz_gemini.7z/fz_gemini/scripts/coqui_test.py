from TTS.api import TTS

tts = TTS(model_name="tts_models/en/ljspeech/glow-tts")
tts.tts_to_file(text="taking a photo in five, four, three, two, one")