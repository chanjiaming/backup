#!/home/eevee/catkin_ws/src/fz_gemini/.venv/bin/python3

import json
import os
import rospy
from std_msgs.msg import String

from config import BASE_PATH
from tts_utils import wait_for_tts, init_tts_subscriber

json_file_path = os.path.join(BASE_PATH, "guest_details.json")  # Path to the JSON file

def load_guest_details():
    try:
        with open(json_file_path, 'r') as file:
            return json.load(file)
    except json.JSONDecodeError as e:
        rospy.logerr("Error reading JSON file: %s", e)
        return []

def parse_clothing(clothing_str):
    """Extract individual clothing items from a string like '1 hat(s), 1 dress(s)'."""
    items = clothing_str.split(',')
    parsed_items = []
    for item in items:
        # Remove quantity and trim spaces
        parsed_item = item.strip().split(' ')[1] if ' ' in item else item.strip()
        parsed_items.append(parsed_item)
    return parsed_items

def find_unique_features(guest, all_guests, feature_key, tracked_clothing):
    guest_feature = guest.get(feature_key, 'N/A')

    # Skip N/A values
    if guest_feature == 'N/A':
        return None

    # Handle single value features (e.g., Gender, Age, Wears Glasses, Wears Mask)
    if isinstance(guest_feature, str) and feature_key != "Clothing":
        is_unique = all(
            guest_feature != other_guest.get(feature_key, 'N/A')
            for other_guest in all_guests if other_guest != guest
        )
        return guest_feature if is_unique else None

    # Handle Clothing by parsing it into individual items
    if feature_key == "Clothing" and isinstance(guest_feature, str):
        clothing_items = parse_clothing(guest_feature)
        unique_items = []
        for item in clothing_items:
            # Only consider it unique if no other guest has it and it hasn't been tracked
            is_unique = all(
                item not in parse_clothing(other_guest.get(feature_key, '')) for other_guest in all_guests if other_guest != guest
            )
            if is_unique and item not in tracked_clothing:
                unique_items.append(item)
                tracked_clothing.add(item)

        return ", ".join(unique_items) if unique_items else None

def compare_guests_offline(guest_list):
    if not guest_list:
        rospy.logwarn("No guests to compare.")
        return "No guests to compare."

    comparison_results = []
    tracked_clothing = set()  # Track clothing items across all guests

    for guest in guest_list:
        unique_features = []

        # Find unique features for Gender, Age, Wears Glasses, Wears Mask
        for feature_key in ["Gender", "Age", "Wears Glasses", "Wears Mask"]:
            unique_feature = find_unique_features(guest, guest_list, feature_key, tracked_clothing)
            if unique_feature and f"{feature_key.lower()}: {unique_feature}" not in unique_features:
                unique_features.append(f"{feature_key.lower()}: {unique_feature}")

        # Handle Clothing separately to avoid repetition
        clothing_features = find_unique_features(guest, guest_list, "Clothing", tracked_clothing)
        if clothing_features:
            unique_features.append(f"clothing: {clothing_features}")

        if unique_features:
            feature_str = " and ".join(unique_features)
            result = f"Guest {guest['Guest ID']}, {guest['Name']} is the only one with {feature_str}."
        else:
            result = f"Guest {guest['Guest ID']}, {guest['Name']} has no unique features."

        comparison_results.append(result)

    return "\n".join(comparison_results) if comparison_results else "No unique features found among guests."

def main():
    rospy.init_node('offline_guest_comparison_node', anonymous=True)
    pub_speak = rospy.Publisher('speech_to_speak', String, queue_size=10)
    init_tts_subscriber()

    guest_list = load_guest_details()
    comparison_result = compare_guests_offline(guest_list)

    if comparison_result == "No guests to compare.":
        rospy.loginfo("No guests to compare, exiting.")
        return

    # Print or log the result
    rospy.loginfo(f"Offline Comparison Result: {comparison_result}")

    # Publish the comparison result to the TTS topic
    pub_speak.publish(comparison_result)
    wait_for_tts()
    
if __name__ == "__main__":
    main()
