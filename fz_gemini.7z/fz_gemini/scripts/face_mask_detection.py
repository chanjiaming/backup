#!/home/eevee/catkin_ws/src/fz_gemini/.venv/bin/python3

import sys
import os

# Add the parent directory (where face_mask_utils is located) to the Python path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import rospy
import cv2
import numpy as np
import json
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
from std_srvs.srv import Trigger, TriggerResponse

from face_mask_utils.anchor_generator import generate_anchors
from face_mask_utils.anchor_decode import decode_bbox
from face_mask_utils.nms import single_class_non_max_suppression
from config import BASE_PATH

class FaceMaskDetectionService:
    def __init__(self):
        self.bridge = CvBridge()
        self.proto_path = os.path.join(BASE_PATH, "face_mask_model/face_mask_detection.prototxt")
        self.model_path = os.path.join(BASE_PATH, "face_mask_model/face_mask_detection.caffemodel")
        self.net = cv2.dnn.readNet(self.model_path, self.proto_path)

        rospy.Service('face_mask_detection', Trigger, self.handle_detection)
        rospy.loginfo("Face Mask Detection Service is ready.")

        # Configuration for anchors (based on your previous code)
        feature_map_sizes = [[33, 33], [17, 17], [9, 9], [5, 5], [3, 3]]
        anchor_sizes = [[0.04, 0.056], [0.08, 0.11], [0.16, 0.22], [0.32, 0.45], [0.64, 0.72]]
        anchor_ratios = [[1, 0.62, 0.42]] * 5

        # Generate anchors
        self.anchors = generate_anchors(feature_map_sizes, anchor_sizes, anchor_ratios)
        self.anchors_exp = np.expand_dims(self.anchors, axis=0)

        self.id2class = {0: 'Mask', 1: 'No Mask'}
        self.colors = ((0, 255, 0), (255, 0, 0))

    def handle_detection(self, req):
        image_path = os.path.join(BASE_PATH, "img/captured_image.jpg")
        frame = cv2.imread(image_path)
        
        if frame is None:
            rospy.logerr("Failed to load the image for face mask detection.")
            return TriggerResponse(success=False, message="Failed to load the image.")

        result_img, detection_result = self.inference(self.net, frame, target_shape=(260, 260), conf_thresh=0.5)

        # Save the image with bounding boxes
        save_path = os.path.join(BASE_PATH, "img/mask_detected.jpg")
        cv2.imwrite(save_path, result_img)
        rospy.loginfo(f"Saved image with bounding box to {save_path}")

        # Create a dictionary with the detection information
        detection_info = {"wears_mask": detection_result}

        # Convert the dictionary to a JSON string
        json_message = json.dumps(detection_info)

        return TriggerResponse(success=True, message=json_message)
        # return TriggerResponse(success=True, message=f"The guest has {detection_result}.")

    def getOutputsNames(self, net):
        layersNames = net.getLayerNames()
        unconnected_out_layers = net.getUnconnectedOutLayers()
        if isinstance(unconnected_out_layers, np.ndarray):
            return [layersNames[i - 1] for i in unconnected_out_layers.flatten()]
        else:
            return [layersNames[unconnected_out_layers - 1]]

    def inference(self, net, image, conf_thresh=0.5, iou_thresh=0.4, target_shape=(160, 160), draw_result=True):
        height, width, _ = image.shape
        blob = cv2.dnn.blobFromImage(image, scalefactor=1 / 255.0, size=target_shape)
        net.setInput(blob)
        y_bboxes_output, y_cls_output = net.forward(self.getOutputsNames(net))
        y_bboxes = decode_bbox(self.anchors_exp, y_bboxes_output)[0]
        y_cls = y_cls_output[0]
        bbox_max_scores = np.max(y_cls, axis=1)
        bbox_max_score_classes = np.argmax(y_cls, axis=1)
        keep_idxs = single_class_non_max_suppression(y_bboxes, bbox_max_scores, conf_thresh=conf_thresh, iou_thresh=iou_thresh)
        
        tl = round(0.002 * (height + width) * 0.5) + 1  # Line thickness
        detection_result = "No Face Detected"  # Default message

        for idx in keep_idxs:
            conf = float(bbox_max_scores[idx])
            class_id = bbox_max_score_classes[idx]
            bbox = y_bboxes[idx]
            xmin = max(0, int(bbox[0] * width))
            ymin = max(0, int(bbox[1] * height))
            xmax = min(int(bbox[2] * width), width)
            ymax = min(int(bbox[3] * height), height)
            if draw_result:
                cv2.rectangle(image, (xmin, ymin), (xmax, ymax), self.colors[class_id], thickness=tl)
                cv2.putText(image, "%s: %.2f" % (self.id2class[class_id], conf), (xmin + 2, ymin - 2),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, self.colors[class_id])
            
            detection_result = self.id2class[class_id]  # Update detection result
        
        return image, detection_result

if __name__ == "__main__":
    rospy.init_node('face_mask_detection_service')
    FaceMaskDetectionService()
    rospy.spin()
